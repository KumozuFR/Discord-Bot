Features


Linking Rewards
Discord Boosting Rewards
Role Sync
CustomConfig
mcverify
mclink
Addon
Plugin
Multiple Server Support
Sync Minecraft Username -> Discord Usernames
Lloyd's Tickets Addon Support
MCLookup
MCHistory